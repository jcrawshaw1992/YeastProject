/*

Copyright (c) 2005-2013, University of Oxford.
All rights reserved.

University of Oxford means the Chancellor, Masters and Scholars of the
University of Oxford, having an administrative office at Wellington
Square, Oxford OX1 2JD, UK.

This file is part of Chaste.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the University of Oxford nor the names of its
   contributors may be used to endorse or promote products derived from this
   software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "AspectRatioConstraintPottsUpdateRule.hpp"

template<unsigned DIM>
AspectRatioConstraintPottsUpdateRule<DIM>::AspectRatioConstraintPottsUpdateRule()
    : AbstractPottsUpdateRule<DIM>(),
      mAspectRatioEnergyParameter(0.5), // @todo Made up defaults
      mTargetAspectRatio(40.0)
{
}

template<unsigned DIM>
AspectRatioConstraintPottsUpdateRule<DIM>::~AspectRatioConstraintPottsUpdateRule()
{
}

template<unsigned DIM>
double AspectRatioConstraintPottsUpdateRule<DIM>::EvaluateHamiltonianContribution(unsigned currentNodeIndex,
                                                                        unsigned targetNodeIndex,
                                                                        PottsBasedCellPopulation<DIM>& rCellPopulation)
{
	assert(DIM==2 || DIM==3);

    double delta_H = 0.0;

    std::set<unsigned> containing_elements = rCellPopulation.GetNode(currentNodeIndex)->rGetContainingElementIndices();
    std::set<unsigned> new_location_containing_elements = rCellPopulation.GetNode(targetNodeIndex)->rGetContainingElementIndices();

    bool current_node_contained = !containing_elements.empty();
    bool target_node_contained = !new_location_containing_elements.empty();

    // Every node must each be in at most one element
    assert(new_location_containing_elements.size() < 2);

    if (!current_node_contained && !target_node_contained)
    {
        EXCEPTION("At least one of the current node or target node must be in an element.");
    }

    if (current_node_contained && target_node_contained)
    {
        if (*(new_location_containing_elements.begin()) == *(containing_elements.begin()))
        {
            EXCEPTION("The current node and target node must not be in the same element.");
        }
    }

    if (current_node_contained) // current node is in an element
    {
        unsigned current_element = (*containing_elements.begin());
        PottsElement<DIM>* pCurrentElement = rCellPopulation.rGetMesh().GetElement(current_element);

        double current_aspect_ratio = pCurrentElement->GetAspectRatio();
        double current_aspect_ratio_difference = current_aspect_ratio - mTargetAspectRatio;

        // Add node to element here
        Node<DIM>* pTargetNode = rCellPopulation.rGetMesh().GetNode(targetNodeIndex);
		pCurrentElement->AddNode(pTargetNode);

        double current_aspect_ratio_after_switch =  pCurrentElement->GetAspectRatio();
        double current_aspect_ratio_difference_after_switch= current_aspect_ratio_after_switch - mTargetAspectRatio;

        // Remove node after calculating aspect ratio
        pCurrentElement->DeleteNode(pCurrentElement->GetNodeLocalIndex(pTargetNode->GetIndex()));

        delta_H += mAspectRatioEnergyParameter*(current_aspect_ratio_difference_after_switch*current_aspect_ratio_difference_after_switch - current_aspect_ratio_difference*current_aspect_ratio_difference);
    }
    if (target_node_contained) // target node is in an element
    {
        unsigned target_element = (*new_location_containing_elements.begin());
        PottsElement<DIM>* pTargetElement = rCellPopulation.rGetMesh().GetElement(target_element);

        double target_aspect_ratio = pTargetElement->GetAspectRatio();
        double target_aspect_ratio_difference = target_aspect_ratio - mTargetAspectRatio;
        double target_aspect_ratio_after_switch;

        // Remove node from element here
        if (pTargetElement->GetNumNodes() > 1)
        {
        	Node<DIM>* pTargetNode = rCellPopulation.rGetMesh().GetNode(targetNodeIndex);
        	pTargetElement->DeleteNode(pTargetElement->GetNodeLocalIndex(pTargetNode->GetIndex()));

        	target_aspect_ratio_after_switch = pTargetElement->GetAspectRatio();

        	// Add node back after calculating aspect ratio
        	pTargetElement->AddNode(pTargetNode);
        }
        else
        {
        	assert(target_aspect_ratio ==1.0);
        	target_aspect_ratio_after_switch = 1.0;
        }
        double target_aspect_ratio_difference_after_switch= target_aspect_ratio_after_switch - mTargetAspectRatio;



        delta_H += mAspectRatioEnergyParameter*(target_aspect_ratio_difference_after_switch*target_aspect_ratio_difference_after_switch - target_aspect_ratio_difference*target_aspect_ratio_difference);
    }

    return delta_H;
}

template<unsigned DIM>
double AspectRatioConstraintPottsUpdateRule<DIM>::GetAspectRatioEnergyParameter()
{
    return mAspectRatioEnergyParameter;
}

template<unsigned DIM>
void AspectRatioConstraintPottsUpdateRule<DIM>::SetAspectRatioEnergyParameter(double aspectRatioEnergyParameter)
{
    mAspectRatioEnergyParameter = aspectRatioEnergyParameter;
}

template<unsigned DIM>
double AspectRatioConstraintPottsUpdateRule<DIM>::GetTargetAspectRatio() const
{
    return mTargetAspectRatio;
}

template<unsigned DIM>
void AspectRatioConstraintPottsUpdateRule<DIM>::SetTargetAspectRatio(double targetAspectRatio)
{
    assert(targetAspectRatio >= 0.0);
    mTargetAspectRatio = targetAspectRatio;
}

template<unsigned DIM>
void AspectRatioConstraintPottsUpdateRule<DIM>::OutputUpdateRuleParameters(out_stream& rParamsFile)
{
    *rParamsFile << "\t\t\t<AspectRatioEnergyParameter>" << mAspectRatioEnergyParameter << "</AspectRatioEnergyParameter>\n";
    *rParamsFile << "\t\t\t<TargetAspectRatio>" << mTargetAspectRatio << "</TargetAspectRatio>\n";

    // Call method on direct parent class
    AbstractPottsUpdateRule<DIM>::OutputUpdateRuleParameters(rParamsFile);
}


/////////////////////////////////////////////////////////////////////////////
// Explicit instantiation
/////////////////////////////////////////////////////////////////////////////

template class AspectRatioConstraintPottsUpdateRule<1>;
template class AspectRatioConstraintPottsUpdateRule<2>;
template class AspectRatioConstraintPottsUpdateRule<3>;

// Serialization for Boost >= 1.36
#include "SerializationExportWrapperForCpp.hpp"
EXPORT_TEMPLATE_CLASS_SAME_DIMS(AspectRatioConstraintPottsUpdateRule)
