/*

Copyright (c) 2005-2014, University of Oxford.
All rights reserved.

University of Oxford means the Chancellor, Masters and Scholars of the
University of Oxford, having an administrative office at Wellington
Square, Oxford OX1 2JD, UK.

This file is part of Chaste.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the University of Oxford nor the names of its
   contributors may be used to endorse or promote products derived from this
   software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "ArbitrarySurfaceAreaConstraintPottsUpdateRule.hpp"
#include "PottsArbitrarySurfaceIn3DMesh.hpp"
#include "Debug.hpp"
#include "CPMGTPaseEventHandler.hpp"

template<unsigned DIM>
ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::ArbitrarySurfaceAreaConstraintPottsUpdateRule()
    : AbstractPottsUpdateRule<DIM>(),
	  mSurfaceAreaEnergyParameter(0.5), // Educated guess
	  mTargetSurfaceArea(16.0) // Defaults to a 4*4 cell size

{
        /// \todo Default values don't apply in 3D.
}

template<unsigned DIM>
ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::~ArbitrarySurfaceAreaConstraintPottsUpdateRule()
{
}

template<unsigned DIM>
double ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::EvaluateHamiltonianContribution(unsigned currentNodeIndex,
                                                                        unsigned targetNodeIndex,
                                                                        PottsBasedCellPopulation<DIM>& rCellPopulation)
{
    CPMGTPaseEventHandler::BeginEvent(CPMGTPaseEventHandler::SURFACE);

    double delta_H = 0.0;

    std::set<unsigned> containing_elements = rCellPopulation.GetNode(currentNodeIndex)->rGetContainingElementIndices();
    std::set<unsigned> new_location_containing_elements = rCellPopulation.GetNode(targetNodeIndex)->rGetContainingElementIndices();

    bool current_node_contained = !containing_elements.empty();
    bool target_node_contained = !new_location_containing_elements.empty();

    // Every node must each be in at most one element
    assert(new_location_containing_elements.size() < 2);

    if (!current_node_contained && !target_node_contained)
    {
        EXCEPTION("At least one of the current node or target node must be in an element.");
    }

    if (current_node_contained && target_node_contained)
    {
        if (*(new_location_containing_elements.begin()) == *(containing_elements.begin()))
        {
            EXCEPTION("The current node and target node must not be in the same element.");
        }
    }

    //double surface_area_target_lattice_site = static_cast<PottsArbitrarySurfaceIn3DMesh<DIM>*>(&rCellPopulation.rGetMesh())->GetSurfaceAreaOfLatticeSite(targetNodeIndex);

    if (current_node_contained) // current node is in an element
    {
           unsigned current_element = (*containing_elements.begin());
           PottsElement<DIM>* pCurrentElement = rCellPopulation.rGetMesh().GetElement(current_element);

           //double current_surface_area = pCurrentElement->GetSurfaceArea();
           double current_surface_area  = rCellPopulation.rGetMesh().GetSurfaceAreaOfElement(current_element);
           double current_surface_area_difference = current_surface_area - mTargetSurfaceArea;

           // Mock change of spin to call GetSurfaceAreaOfElement with new configuration
           Node<DIM>* pTargetNode = rCellPopulation.rGetMesh().GetNode(targetNodeIndex);
           pCurrentElement->AddNode(pTargetNode);
           if (target_node_contained)
           {
               unsigned target_element = (*new_location_containing_elements.begin());
               PottsElement<DIM>* pTargetElement = rCellPopulation.rGetMesh().GetElement(target_element);
               pTargetElement->DeleteNode(pTargetElement->GetNodeLocalIndex(pTargetNode->GetIndex()));
           }

           double current_surface_area_after_switch  = rCellPopulation.rGetMesh().GetSurfaceAreaOfElement(current_element);
           double current_surface_area_difference_after_switch= current_surface_area_after_switch - mTargetSurfaceArea;

           // Undo mocked change
           pCurrentElement->DeleteNode(pCurrentElement->GetNodeLocalIndex(pTargetNode->GetIndex()));
           if (target_node_contained)
           {
               unsigned target_element = (*new_location_containing_elements.begin());
               PottsElement<DIM>* pTargetElement = rCellPopulation.rGetMesh().GetElement(target_element);
               pTargetElement->AddNode(pTargetNode);
           }

           delta_H += mSurfaceAreaEnergyParameter*(current_surface_area_difference_after_switch*current_surface_area_difference_after_switch - current_surface_area_difference*current_surface_area_difference);
       }
       if (target_node_contained) // target node is in an element
       {
           unsigned target_element = (*new_location_containing_elements.begin());
           PottsElement<DIM>* pTargetElement = rCellPopulation.rGetMesh().GetElement(target_element);

           double target_surface_area  = rCellPopulation.rGetMesh().GetSurfaceAreaOfElement(target_element);
           double target_surface_area_difference = target_surface_area - mTargetSurfaceArea;

           Node<DIM>* pTargetNode = rCellPopulation.rGetMesh().GetNode(targetNodeIndex);
           pTargetElement->DeleteNode(pTargetElement->GetNodeLocalIndex(pTargetNode->GetIndex()));

           double target_surface_area_after_switch  = rCellPopulation.rGetMesh().GetSurfaceAreaOfElement(target_element);
           double target_surface_area_difference_after_switch= target_surface_area_after_switch - mTargetSurfaceArea;

           // Add node back after calculating aspect ratio
           pTargetElement->AddNode(pTargetNode);

           delta_H += mSurfaceAreaEnergyParameter*(target_surface_area_difference_after_switch*target_surface_area_difference_after_switch - target_surface_area_difference*target_surface_area_difference);
       }

       CPMGTPaseEventHandler::EndEvent(CPMGTPaseEventHandler::SURFACE);

       return delta_H;
   }

template<unsigned DIM>
double ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::GetSurfaceAreaEnergyParameter()
{
    return mSurfaceAreaEnergyParameter;
}

template<unsigned DIM>
void ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::SetSurfaceAreaEnergyParameter(double surfaceAreaEnergyParameter)
{
	mSurfaceAreaEnergyParameter = surfaceAreaEnergyParameter;
}

template<unsigned DIM>
double ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::GetTargetSurfaceArea() const
{
    return mTargetSurfaceArea;
}

template<unsigned DIM>
void ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::SetTargetSurfaceArea(double targetSurfaceArea)
{
    assert(targetSurfaceArea >= 0.0);
    mTargetSurfaceArea = targetSurfaceArea;
}

template<unsigned DIM>
void ArbitrarySurfaceAreaConstraintPottsUpdateRule<DIM>::OutputUpdateRuleParameters(out_stream& rParamsFile)
{
    *rParamsFile << "\t\t\t<SurfaceAreaEnergyParameter >" << mSurfaceAreaEnergyParameter << "</SurfaceAreaEnergyParameter >\n";
    *rParamsFile << "\t\t\t<TargetSurfaceArea>" << mTargetSurfaceArea << "</TargetSurfaceArea>\n";

    // Call method on direct parent class
    AbstractPottsUpdateRule<DIM>::OutputUpdateRuleParameters(rParamsFile);
}

/////////////////////////////////////////////////////////////////////////////
// Explicit instantiation
/////////////////////////////////////////////////////////////////////////////

//template class ArbitraryVolumeConstraintPottsUpdateRule<1>;
template class ArbitrarySurfaceAreaConstraintPottsUpdateRule<2>;
template class ArbitrarySurfaceAreaConstraintPottsUpdateRule<3>;

// Serialization for Boost >= 1.36
#include "SerializationExportWrapperForCpp.hpp"
//EXPORT_TEMPLATE_CLASS_SAME_DIMS(ArbitraryVolumeConstraintPottsUpdateRule)
EXPORT_TEMPLATE_CLASS1(ArbitrarySurfaceAreaConstraintPottsUpdateRule, 2)
EXPORT_TEMPLATE_CLASS1(ArbitrarySurfaceAreaConstraintPottsUpdateRule, 3)
