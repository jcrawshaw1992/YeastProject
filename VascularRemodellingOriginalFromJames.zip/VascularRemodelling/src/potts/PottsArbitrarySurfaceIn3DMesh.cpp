/*

Copyright (c) 2005-2014, University of Oxford.
All rights reserved.

University of Oxford means the Chancellor, Masters and Scholars of the
University of Oxford, having an administrative office at Wellington
Square, Oxford OX1 2JD, UK.

This file is part of Chaste.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the University of Oxford nor the names of its
   contributors may be used to endorse or promote products derived from this
   software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "PottsArbitrarySurfaceIn3DMesh.hpp"
#include <algorithm>
#include "UblasCustomFunctions.hpp"
#include "Debug.hpp"
#include <utility>

template<unsigned SPACE_DIM>
PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::PottsArbitrarySurfaceIn3DMesh(std::vector<Node<SPACE_DIM>*> nodes,
                                                                        std::vector<PottsElement<SPACE_DIM>*> pottsElements,
                                                                        std::vector< std::set<unsigned> > vonNeumannNeighbouringNodeIndices,
                                                                        std::vector< std::set<unsigned> > mooreNeighbouringNodeIndices,
                                                                        MutableMesh<2,SPACE_DIM>* pDelaunayMesh) :
    PottsMesh<SPACE_DIM>(nodes, pottsElements, vonNeumannNeighbouringNodeIndices, mooreNeighbouringNodeIndices),
    mpDelaunayMesh(pDelaunayMesh)
{
    assert(SPACE_DIM==2 || SPACE_DIM==3);
}

template<unsigned SPACE_DIM>
PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::~PottsArbitrarySurfaceIn3DMesh()
{
}

template<unsigned SPACE_DIM>
double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetVolumeOfLatticeSite(unsigned latticeSiteIndex)
{
    // TODO: This method's output can be computed in the constructor and cached. Cache will need updating after a call to UpdatePottsNodeLocationFromDelaunay
    Element<2,SPACE_DIM>* mesh_element = mpDelaunayMesh->GetElement(latticeSiteIndex);

    c_matrix<double, SPACE_DIM, 2> jacobian;
    double determinant;
    mesh_element->CalculateJacobian(jacobian, determinant);

    return mesh_element->GetVolume(determinant);
}

template<unsigned SPACE_DIM>
double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetVolumeOfElement(unsigned pottsElementIndex)
{
    PottsElement<SPACE_DIM>* p_potts_element = this->GetElement(pottsElementIndex);

    double potts_element_volume = 0.0;

    // An element is made of a number of lattice sites, which are centered around a number of nodes in the Delaunay mesh
    for (unsigned node_index = 0; node_index < p_potts_element->GetNumNodes(); ++node_index)
    {
        potts_element_volume += GetVolumeOfLatticeSite(p_potts_element->GetNodeGlobalIndex(node_index));
    }

    return potts_element_volume;
}

template<unsigned SPACE_DIM>
inline double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::ComputeTriangleArea(const c_vector<double, SPACE_DIM>& vertexA, const c_vector<double, SPACE_DIM>& vertexB, const c_vector<double, SPACE_DIM>& vertexC) const
{
    const c_vector<double, SPACE_DIM> AC = vertexC-vertexA;
    const c_vector<double, SPACE_DIM> AB = vertexB-vertexA;
    return 0.5 * norm_2(VectorProduct(AC, AB));
}

template<unsigned SPACE_DIM>
double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetSurfaceAreaOfLatticeSite(unsigned latticeSiteIndex)
{
    // TODO: This method's output can be computed in the constructor and cached. Cache will need updating after a call to UpdatePottsNodeLocationFromDelaunay
    Element<2,SPACE_DIM>* mesh_element = mpDelaunayMesh->GetElement(latticeSiteIndex);

    /// TODO make this a template parameter and code up the ELEMENT_DIM=3 case
    const unsigned ELEMENT_DIM = 2;

    double lattice_site_area = 0.0;

    for (unsigned local_node_index=0; local_node_index<ELEMENT_DIM+1; ++local_node_index)
    {
        unsigned node_a_local_index = local_node_index;
        unsigned node_b_local_index = (local_node_index+1) % (ELEMENT_DIM+1);

        const c_vector<double, SPACE_DIM>& node_a_location = mesh_element->GetNode(node_a_local_index)->rGetLocation();
        const c_vector<double, SPACE_DIM>& node_b_location = mesh_element->GetNode(node_b_local_index)->rGetLocation();

        lattice_site_area += norm_2(node_a_location - node_b_location);
    }

    return lattice_site_area;
}

template<unsigned SPACE_DIM>
double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetSurfaceAreaOfElement(unsigned pottsElementIndex)
{
    PottsElement<SPACE_DIM>* p_potts_element = this->GetElement(pottsElementIndex);

    double potts_element_surface = 0.0;

    for (unsigned local_lattice_index = 0; local_lattice_index < p_potts_element->GetNumNodes(); ++local_lattice_index)
    {
        unsigned lattice_site_index = p_potts_element->GetNodeGlobalIndex(local_lattice_index);
        potts_element_surface += GetSurfaceAreaOfLatticeSite(lattice_site_index);

        for (std::set<unsigned>::const_iterator neighbour_lattice_index = this->mMooreNeighbouringNodeIndices[lattice_site_index].begin();
             neighbour_lattice_index != this->mMooreNeighbouringNodeIndices[lattice_site_index].end();
             ++neighbour_lattice_index)
        {
            if (DoNodesShareElement(lattice_site_index, *neighbour_lattice_index))
            {
                potts_element_surface -= GetContactAreaBetweenLatticeSite(lattice_site_index,
                                                                          *neighbour_lattice_index);
            }
        }
    }

    return potts_element_surface;
}


template<unsigned SPACE_DIM>
bool PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::DoNodesShareElement(unsigned indexNodeA, unsigned indexNodeB)
{
    std::set<unsigned> node_a_elements = this->GetNode(indexNodeA)->rGetContainingElementIndices();
    std::set<unsigned> node_b_elements = this->GetNode(indexNodeB)->rGetContainingElementIndices();

    bool is_a_medium = node_a_elements.empty();
    bool is_b_medium = node_b_elements.empty();

    if (is_a_medium xor is_b_medium)
    {
        return false;
    }

    if (is_a_medium and is_b_medium)
    {
        return true;
    }
    else
    {
        assert(node_a_elements.size() == 1);
        assert(node_b_elements.size() == 1);
        return *node_a_elements.begin() == *node_b_elements.begin();
    }
}

template<unsigned SPACE_DIM>
double PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetContactAreaBetweenLatticeSite(unsigned index_A, unsigned index_B)
{
    assert(index_A != index_B);

    /// TODO make this a template parameter and code up the ELEMENT_DIM=3 case
    const unsigned ELEMENT_DIM = 2;

    Element<2,SPACE_DIM>* mesh_element_a = mpDelaunayMesh->GetElement(index_A);
    Element<2,SPACE_DIM>* mesh_element_b = mpDelaunayMesh->GetElement(index_B);

    std::vector<Node<SPACE_DIM>*> node_set_a(ELEMENT_DIM+1);
    std::vector<Node<SPACE_DIM>*> node_set_b(ELEMENT_DIM+1);

    for (unsigned local_node_index=0; local_node_index<ELEMENT_DIM+1; ++local_node_index)
    {
        node_set_a[local_node_index] = mesh_element_a->GetNode(local_node_index);
        node_set_b[local_node_index] = mesh_element_b->GetNode(local_node_index);
    }

    std::sort(node_set_a.begin(), node_set_a.end());
    std::sort(node_set_b.begin(), node_set_b.end());

    std::vector<Node<SPACE_DIM>*> node_set_intersecion(ELEMENT_DIM);
    typename std::vector<Node<SPACE_DIM>*>::iterator node_set_intersection_end;
    node_set_intersection_end = std::set_intersection(node_set_a.begin(), node_set_a.end(),
                                                      node_set_b.begin(), node_set_b.end(),
                                                      node_set_intersecion.begin());
    node_set_intersecion.resize(node_set_intersection_end - node_set_intersecion.begin());

    switch (node_set_intersecion.size())
    {
        case 3:
            /// TODO code up for the ELEMENT_DIM=3 case. Use ComputeTriangleArea helper method
            NEVER_REACHED;
        case 2:
        {
            const c_vector<double, SPACE_DIM>& node_a_location = node_set_intersecion[0]->rGetLocation();
            const c_vector<double, SPACE_DIM>& node_b_location = node_set_intersecion[1]->rGetLocation();

            return norm_2(node_a_location - node_b_location);
        }
        case 1:
        case 0:
            return 0.;
        default:
            NEVER_REACHED;
    }
}

template<unsigned SPACE_DIM>
void PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::UpdatePottsNodeLocationFromDelaunay()
{
    typename MutableMesh<2,SPACE_DIM>::ElementIterator delaunay_element_iter = mpDelaunayMesh->GetElementIteratorBegin();
    typename PottsMesh<SPACE_DIM>::NodeIterator potts_node_iter = this->GetNodeIteratorBegin();

    for(;
        delaunay_element_iter != mpDelaunayMesh->GetElementIteratorEnd();
        ++delaunay_element_iter, ++potts_node_iter)
    {
        assert(potts_node_iter->GetIndex() == delaunay_element_iter->GetIndex());
        potts_node_iter->rGetModifiableLocation() = delaunay_element_iter->CalculateCentroid();
    }
}

template<unsigned SPACE_DIM>
MutableMesh<2,SPACE_DIM>* PottsArbitrarySurfaceIn3DMesh<SPACE_DIM>::GetDelaunayMesh()
{
	return mpDelaunayMesh;
}


template class PottsArbitrarySurfaceIn3DMesh<2>;
template class PottsArbitrarySurfaceIn3DMesh<3>;

//#include "SerializationExportWrapperForCpp.hpp"
//EXPORT_TEMPLATE_CLASS1(PottsArbitrarySurfaceIn3DMesh, 2)
//EXPORT_TEMPLATE_CLASS1(PottsArbitrarySurfaceIn3DMesh, 3)
