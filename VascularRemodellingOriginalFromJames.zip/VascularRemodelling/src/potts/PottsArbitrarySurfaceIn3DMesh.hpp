/*

Copyright (c) 2005-2014, University of Oxford.
All rights reserved.

University of Oxford means the Chancellor, Masters and Scholars of the
University of Oxford, having an administrative office at Wellington
Square, Oxford OX1 2JD, UK.

This file is part of Chaste.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the University of Oxford nor the names of its
   contributors may be used to endorse or promote products derived from this
   software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef POTTSARBITRARYSURFACEIN3DMESH_HPP_
#define POTTSARBITRARYSURFACEIN3DMESH_HPP_

#include "PottsMesh.hpp"
#include "MutableMesh.hpp"

template<unsigned SPACE_DIM>
class PottsArbitrarySurfaceIn3DMesh : public PottsMesh<SPACE_DIM>
{

public:

    /**
     * Constructor.
     *
     * @param nodes vector of pointers to nodes
     * @param pottsElements vector of pointers to PottsElements
     * @param vonNeumannNeighbouringNodeIndices vector of set of Moore neighbours for each node
     * @param mooreNeighbouringNodeIndices vector of set of Von Neumann neighbours for each node
     * @param pDelaunayMesh pointer to associated underlying Delaunay mesh
     */
    PottsArbitrarySurfaceIn3DMesh(std::vector<Node<SPACE_DIM>*> nodes,
                                  std::vector<PottsElement<SPACE_DIM>*> pottsElements,
                                  std::vector< std::set<unsigned> > vonNeumannNeighbouringNodeIndices,
                                  std::vector< std::set<unsigned> > mooreNeighbouringNodeIndices,
                                  MutableMesh<2,SPACE_DIM>* pDelaunayMesh);

    virtual ~PottsArbitrarySurfaceIn3DMesh();

    /**
     * Get the volume (or area in 2D, or length in 1D) of a lattice site.
     *
     * @param index the global index of a specified lattice site
     * @return the volume of the lattice site
     */
    double GetVolumeOfLatticeSite(unsigned index);

    /**
     * Get the volume (or area in 2D, or length in 1D) of a PottsElement.
     *
     * @param index the global index of a specified PottsElement element
     * @return the volume of the element
     */
    double GetVolumeOfElement(unsigned index);

    /**
     * Get the surface area (or perimeter in 2D) of a lattice site.
     *
     * @param latticeSiteIndex the global index of a specified lattice site
     * @return the surface area of the lattice site
     */
    double GetSurfaceAreaOfLatticeSite(unsigned latticeSiteIndex);

    /**
     * Compute the surface area (or perimeter in 2D) of a PottsElement.
     *
     * @param index the global index of a specified PottsElement
     * @return the surface area of the element
     */
    double GetSurfaceAreaOfElement(unsigned index);

    /**
     * Compute the contact area (or edge in 2D) between 2 lattice sites.
     *
     * @param index the index of the first lattice site
     * @param index the index of the second lattice site
     * @return the contact area between the sites
     */
    double GetContactAreaBetweenLatticeSite(unsigned index_A, unsigned index_B);

    /**
     * Update the location of the Potts nodes when the underlying Delaunay mesh changes
     */
    void UpdatePottsNodeLocationFromDelaunay();

    /**
     * Get the original triangular mesh used to define the object
     */
    MutableMesh<2,SPACE_DIM>* GetDelaunayMesh();

private:

    inline double ComputeTriangleArea(const c_vector<double, SPACE_DIM>& vertexA, const c_vector<double, SPACE_DIM>& vertexB, const c_vector<double, SPACE_DIM>& vertexC) const;

    /**
     * Test if two nodes (i.e. two lattices sites) are contained in the same element (i.e. have the same spin).
     * Also true if both are part of the medium.
     *
     * @param indexNodeA Global index for node a.
     * @param indexNodeB Global index for node b.
     * @return true if both lattice sites are contained in the same element (including the medium)
     */
    inline bool DoNodesShareElement(unsigned indexNodeA, unsigned indexNodeB);

    /** Pointer to original delaunay surface mesh */
    MutableMesh<2,SPACE_DIM>* mpDelaunayMesh;

};

//#include "SerializationExportWrapper.hpp"
//EXPORT_TEMPLATE_CLASS1(PottsArbitrarySurfaceIn3DMesh, 2)
//EXPORT_TEMPLATE_CLASS1(PottsArbitrarySurfaceIn3DMesh, 3)

#endif /* POTTSARBITRARYSURFACEIN3DMESH_HPP_ */
