#!/usr/bin/env python

import vtk

name = 'cyl_80_104'

# Read the VTU file from disk
vtu_reader = vtk.vtkXMLUnstructuredGridReader()
vtu_reader.SetFileName(name + '.vtu')

# vtkAppendFilter appends one or more datasets together into a single
# unstructured grid
extract_surface_filter = vtk.vtkDataSetSurfaceFilter()
extract_surface_filter.AddInputConnection(vtu_reader.GetOutputPort())

# Write out the data in unstructured grid format
stl_writer = vtk.vtkSTLWriter()
stl_writer.SetInputConnection(extract_surface_filter.GetOutputPort())
stl_writer.SetFileName(name + '.stl')
stl_writer.Write()
