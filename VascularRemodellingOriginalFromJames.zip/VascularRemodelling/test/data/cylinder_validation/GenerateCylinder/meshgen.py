#!/usr/bin/env python
import sys
import quantities as pq
import math
from TriangulatedCylinderSource import TriangulatedCylinderSource
from vtk import vtkXMLUnstructuredGridWriter, vtkSTLWriter, vtkAppendFilter
import argparse
    
if __name__ == '__main__' :
    p = argparse.ArgumentParser()
    p.add_argument(dest='nd', type=int,
                   help='number of sides in the prism approximating the cylinder')
    p.add_argument(dest='nz', type=int,
                   help='number of line segments along the cylinder')
    p.add_argument(dest='l2d', type=int,
                   help='cylinder length to diameter ratio')
    p.add_argument('--stl', dest='stl', action='store_true', help='Generate output in STL format instead of VTU.')
    # p.add_argument(dest='outputfile', default=None,
    #                help='file to output the graph to, none implies plot to screen')
    args = p.parse_args()

    Ma = 0.1 * pq.dimensionless
    tau = 1. * pq.dimensionless
    diameter_phys = 3e-3 * pq.metre
    length_phys = args.l2d * diameter_phys 
    Re = 10 * pq.dimensionless
    kine_visc_phys = 4e-6 * pq.metre**2 / pq.second
    dyn_visc_phys = 3e-6 * pq.pascal * pq.second

    v_max_latt = Ma / math.sqrt(3)
    v_max_phys = Re * kine_visc_phys / diameter_phys

    kine_visc_latt = (tau - 0.5) / 3

    dt_over_dx = v_max_latt / v_max_phys
    dt_over_dxdx = kine_visc_latt / kine_visc_phys

    dx = dt_over_dx / dt_over_dxdx
    dt = dt_over_dx * dx

    diameter_latt = diameter_phys / dx

    pressure_diff = 16 * v_max_phys * dyn_visc_phys * length_phys / diameter_phys**2

    moment_diff_time = diameter_phys**2/kine_visc_phys

    tcs = TriangulatedCylinderSource()

    #filename = args.outputfile
    filename = 'cyl_' + str(args.nd) + '_' + str(args.nz)

    if args.stl:
        filename += '.stl'
        w = vtkSTLWriter()
        source = tcs
    else:
        filename += '.vtu'
        app = vtkAppendFilter()
        app.SetInputConnection(tcs.GetOutputPort())
        w = vtkXMLUnstructuredGridWriter()
        source = app
        
    w.SetInputConnection(source.GetOutputPort())

    tcs.SetRadius(diameter_phys.rescale('mm')/2)
    tcs.SetResolution(args.nd)
    tcs.SetHeight(length_phys.rescale('mm'))
    tcs.SetHeightSegments(args.nz)
    tcs.CappingOff()

    w.SetFileName(filename)

    w.Write()

    print 'Diameter in lattice units is {}. Adjust Ma in script if it goes below 20'.format(diameter_latt)
    print 'Maximum velocity is {}'.format(v_max_phys) 
    print 'Set voxel size to {} in profile file'.format(dx.rescale('mm'))
    print 'Set timestep to {} in profile file'.format(dt)
    print 'Moment diffusion time is {}. Run for {} timesteps'.format(moment_diff_time, moment_diff_time/dt)
    print 'Set inlet pressure to {} in profile file'.format(80 * pq.mmHg + pressure_diff.rescale('mmHg'))
