python meshgen.py 40 52 4 --stl

vmtksurfaceremeshing -ifile cyl_40_52.stl -ofile cyl_40_52_remeshed581.stl -maxarea 0.15
vmtksurfaceremeshing -ifile cyl_40_52.stl -ofile cyl_40_52_remeshed8334.stl -maxarea 0.01
vmtksurfaceremeshing -ifile cyl_40_52.stl -ofile cyl_40_52_remeshed2103.stl -maxarea 0.04
vmtksurfaceremeshing -ifile cyl_40_52.stl -ofile cyl_40_52_remeshed33331.stl -maxarea 0.0025

python STL2VTU.py
