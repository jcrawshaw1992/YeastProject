Use the command below to regenerate the cylinder for prisms with different numbers of sides (currently 15)

python GenerateCylinder/meshgen.py 15 config.stl
