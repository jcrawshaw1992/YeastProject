#!/usr/bin/env python

import vtk

in_name = 'config'
out_name = 'config'

# Read the STL file from disk
stl_reader = vtk.vtkSTLReader()
stl_reader.SetFileName(in_name + '.stl')

# vtkAppendFilter appends one or more datasets together into a single
# unstructured grid
stl_to_vtu_filter = vtk.vtkAppendFilter()
stl_to_vtu_filter.AddInputConnection(stl_reader.GetOutputPort())

# Write out the data in unstructured grid format
vtu_writer = vtk.vtkXMLUnstructuredGridWriter()
vtu_writer.SetInputConnection(stl_to_vtu_filter.GetOutputPort())
vtu_writer.SetFileName(out_name + '.vtu')
vtu_writer.Write()
