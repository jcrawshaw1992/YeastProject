

#ifndef LINEARSPRINGFORCE_HPP_
#define LINEARSPRINGFORCE_HPP_

#include "AbstractForce.hpp"
#include "MeshBasedCellPopulation.hpp"
#include "NodeBasedCellPopulation.hpp"
#include "AbstractCellPopulation.hpp"
/**
 * An abstract class for two-body force laws.
 */
template<unsigned  ELEMENT_DIM, unsigned SPACE_DIM=ELEMENT_DIM>
class LinearSpringForce : public AbstractForce<ELEMENT_DIM, SPACE_DIM>
{
private:

    /** Needed for serialization. */
    friend class boost::serialization::access;
    /**
     * Archive the object and its member variables.
     *
     * @param archive the archive
     * @param version the current version of this class
     */
    template<class Archive>
    void serialize(Archive & archive, const unsigned int version)
    {
        archive & boost::serialization::base_object<AbstractForce<ELEMENT_DIM,SPACE_DIM> >(*this);
        archive & mUseCutOffLength;
        archive & mMechanicsCutOffLength;
    }

protected:

    /** Whether to have zero force if the cells are far enough apart. */
    bool mUseCutOffLength;

    /** Mechanics cut off length. */
    double mMechanicsCutOffLength;

public:

    /**
     * Constructor.
     */
    LinearSpringForce();

    /**
     * Whether the force is using a cut of length.
     *
     * @return mUseCutOffLength
     */
    bool GetUseCutOffLength();

    /**
     * Use a cutoff point, ie specify zero force if two cells are greater
     * than the cutoff distance apart.
     *
     * @param cutOffLength the cutoff to use
     */
    void SetCutOffLength(double cutOffLength);

    /**
     * Get the cutoff length.
     *
     * @return mCutOffLength
     */
    double GetCutOffLength();

    /**
     * Calculates the force between two nodes.
     *
     * Note that this assumes they are connected and is called by rCalculateVelocitiesOfEachNode().
     *
     * As this method is pure virtual, it must be overridden
     * in subclasses.
     *
     * @param nodeAGlobalIndex index of one neighbouring node
     * @param nodeBGlobalIndex index of the other neighbouring node
     * @param rCellPopulation the cell population
     *
     * @return The force exerted on Node A by Node B.
     */
    virtual c_vector<double, SPACE_DIM> CalculateForceBetweenNodes(unsigned nodeAGlobalIndex, unsigned nodeBGlobalIndex, AbstractCellPopulation<ELEMENT_DIM, SPACE_DIM>& rCellPopulation)=0;

    /**
     * Overridden AddForceContribution() method.
     *
     * @param rCellPopulation reference to the cell population
     */
    void AddForceContribution(AbstractCellPopulation<ELEMENT_DIM,SPACE_DIM>& rCellPopulation);

    /**
     * Overridden OutputForceParameters() method.
     *
     * @param rParamsFile the file stream to which the parameters are output
     */
    virtual void OutputForceParameters(out_stream& rParamsFile);

    /**
     * Overridden WriteDataToVisualizerSetupFile() method.
     * Write any data necessary to a visualization setup file.
     * Used by AbstractCellBasedSimulation::WriteVisualizerSetupFile().
     *
     * @param pVizSetupFile a visualization setup file
     */
    virtual void WriteDataToVisualizerSetupFile(out_stream& pVizSetupFile);
};

#endif /*LinearSpringForce_HPP_*/
