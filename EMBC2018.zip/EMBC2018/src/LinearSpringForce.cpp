

#include "LinearSpringForce.hpp"
#include "Debug.hpp"

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::LinearSpringForce()
   : AbstractForce<ELEMENT_DIM,SPACE_DIM>(),
     mUseCutOffLength(false),
     mMechanicsCutOffLength(DBL_MAX)
{
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
bool LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::GetUseCutOffLength()
{
    return mUseCutOffLength;
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
void LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::SetCutOffLength(double cutOffLength)
{
    assert(cutOffLength > 0.0);
    mUseCutOffLength = true;
    mMechanicsCutOffLength = cutOffLength;
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
double LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::GetCutOffLength()
{
    return mMechanicsCutOffLength;
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
void LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::AddForceContribution(AbstractCellPopulation<ELEMENT_DIM,SPACE_DIM>& rCellPopulation)
{
    // Throw an exception message if not using a subclass of AbstractCentreBasedCellPopulation
    if (dynamic_cast<AbstractCentreBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>*>(&rCellPopulation) == nullptr)
    {
        EXCEPTION("Subclasses of LinearSpringForce are to be used with subclasses of AbstractCentreBasedCellPopulation only");
    }

    ///\todo this could be tidied by using the rGetNodePairs for all populations and moving the below calculation into the MutableMesh.
    if (bool(dynamic_cast<MeshBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>*>(&rCellPopulation)))
    {
        MeshBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>* p_static_cast_cell_population = static_cast<MeshBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>*>(&rCellPopulation);

        // Iterate over all springs and add force contributions
        for (typename MeshBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>::SpringIterator spring_iterator = p_static_cast_cell_population->SpringsBegin();
             spring_iterator != p_static_cast_cell_population->SpringsEnd();
             ++spring_iterator)
        {
            unsigned nodeA_global_index = spring_iterator.GetNodeA()->GetIndex();
            unsigned nodeB_global_index = spring_iterator.GetNodeB()->GetIndex();

        // Find the pointer for each of the nodes
            CellPtr pCellA =  rCellPopulation.GetCellUsingLocationIndex(nodeA_global_index); // This gives us the pointer based on the index.
            CellPtr pCellB =  rCellPopulation.GetCellUsingLocationIndex(nodeB_global_index);


           // Calculate the force between nodes
            double volumeA =  0.3 * rCellPopulation.GetVolumeOfCell(pCellA);
            double volumeB =  0.3 * rCellPopulation.GetVolumeOfCell(pCellB);

            // Calculate the force between nodes
            c_vector<double, SPACE_DIM> force = CalculateForceBetweenNodes(nodeA_global_index, nodeB_global_index, rCellPopulation);

            // Add the force contribution to each node
            c_vector<double, SPACE_DIM> negative_force = -1.0*force;
            spring_iterator.GetNodeB()->AddAppliedForceContribution(negative_force/volumeB);
            spring_iterator.GetNodeA()->AddAppliedForceContribution(force/volumeA);
        
        }
    }

    else    // This is a NodeBasedCellPopulation
    {
        AbstractCentreBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>* p_static_cast_cell_population = static_cast<AbstractCentreBasedCellPopulation<ELEMENT_DIM,SPACE_DIM>*>(&rCellPopulation);

        std::vector< std::pair<Node<SPACE_DIM>*, Node<SPACE_DIM>* > >& r_node_pairs = p_static_cast_cell_population->rGetNodePairs();

        for (typename std::vector< std::pair<Node<SPACE_DIM>*, Node<SPACE_DIM>* > >::iterator iter = r_node_pairs.begin();
            iter != r_node_pairs.end();
            iter++)
        {
            std::pair<Node<SPACE_DIM>*, Node<SPACE_DIM>* > pair = *iter;

            unsigned node_a_index = pair.first->GetIndex();
            unsigned node_b_index = pair.second->GetIndex();

            CellPtr pCellA = rCellPopulation.GetCellUsingLocationIndex(node_a_index); // This gives us the pointer based on the index.
            CellPtr pCellB = rCellPopulation.GetCellUsingLocationIndex(node_b_index);
           // Calculate the force between nodes
            double volumeA =  0.3* rCellPopulation.GetVolumeOfCell(pCellA);
            double volumeB =  0.3*  rCellPopulation.GetVolumeOfCell(pCellB);

            // Calculate the force between nodes
            c_vector<double, SPACE_DIM> force = CalculateForceBetweenNodes(node_a_index, node_b_index, rCellPopulation);
            for (unsigned j=0; j<SPACE_DIM; j++)
            {
                assert(!std::isnan(force[j]));
            }

            // Add the force contribution to each node
            c_vector<double, SPACE_DIM> negative_force = -1.0*force;
            pair.first->AddAppliedForceContribution(force/volumeA);
            pair.second->AddAppliedForceContribution(negative_force/volumeA);
        
        }
    }
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
void LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::OutputForceParameters(out_stream& rParamsFile)
{
    *rParamsFile << "\t\t\t<UseCutOffLength>" << mUseCutOffLength << "</UseCutOffLength>\n";
    *rParamsFile << "\t\t\t<CutOffLength>" << mMechanicsCutOffLength << "</CutOffLength>\n";

    // Call method on direct parent class
    AbstractForce<ELEMENT_DIM,SPACE_DIM>::OutputForceParameters(rParamsFile);
}

template<unsigned ELEMENT_DIM, unsigned SPACE_DIM>
void LinearSpringForce<ELEMENT_DIM,SPACE_DIM>::WriteDataToVisualizerSetupFile(out_stream& pVizSetupFile)
{
    *pVizSetupFile << "Cutoff\t" << mMechanicsCutOffLength << "\n";
}





// Explicit instantiation
template class LinearSpringForce<1,1>;
template class LinearSpringForce<1,2>;
template class LinearSpringForce<2,2>;
template class LinearSpringForce<1,3>;
template class LinearSpringForce<2,3>;
template class LinearSpringForce<3,3>;
