#!/bin/bash
mpirun -np 1 hemelb -in /Users/jcrawshaw/Documents/ChasteWorkingDirectory/FlowFolder/config.xml
