# import vtk
# from vtk.util import numpy_support
# import vtk
# import numpy as np
# from subprocess import call


# import subprocess
# import os





if __name__=="__main__":
    print "Hi from Python :) "